To set up the project:
Open terminal in the COMP3753 Project folder:

> npm install
> node server.js

then visit http://localhost:5000/